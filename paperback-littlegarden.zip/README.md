# Paperback - Little Garden Source

Source personnalisée pour [Paperback](https://paperback.moe).

Site : https://littlexgarden.com

## Installation

1. Uploadez ce repo sur votre compte GitHub.
2. Activez **GitHub Pages** dans les paramètres (branche `main`).
3. Dans Paperback, ajoutez le repo en tant que source externe :
   - Paramètres → Extensions → Ajouter un repo personnalisé
   - URL : https://<ton-pseudo>.github.io/paperback-littlegarden/
4. Installez la source "Little Garden (FR)".
